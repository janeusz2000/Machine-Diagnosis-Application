Entry point is inside lab3App/main.py
